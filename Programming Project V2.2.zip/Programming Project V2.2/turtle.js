/// <reference path="./lib/Intellisense/js-turtle_hy.ts" />
//DOCUMENTATION: https://hanumanum.github.io/js-turtle/
/*
showGrid(20);      
forward(distance)  
right(angle)       
left(angle) 	   
goto(x,y) 	       
clear() 	       
penup() 	       
pendown() 	       
reset() 	       
angle(angle)	   
width(width)       

color(r,g,b)
color([r,g,b])
color("red")
color("#ff0000")
*/
function gciVandak() {
    width(4)

    goto(-300, 300)

    right(90)
    forward(600)

    right(90)
    forward(600)

    goto(300, -300)

    right(90)
    forward(600)

    right(90)
    forward(600)

    goto(-100, 300)

    left(180)
    forward(600)

    goto(100, 300)
    forward(600)

    goto(-300, 100)

    right(270)
    forward(600)

    goto(-300, -100)
    forward(600)

    goto(0, 0)
    left(90)
}

gciVandak()

function gciX(x, y) {
    goto(x, y)
    right(135)
    forward(280)

    penup()
    right(135)
    forward(195)
    right(135)
    pendown()

    forward(280)
    left(45)
}

function gciO(x, y) {
    width(4)
    goto(x,y)
    for (i = 1; i < 361; i++) {
        right(1)
        forward(1)
    }
}


function gcel() {
    let a = +prompt()
    //   1   //

    if (a == 1) {
        gciX(-300, 300)
    }

    //   2   //

    if (a == 2) {
        gciX(-100, 300)
    }

    //   3   //

    if (a == 3) {
        gciX(100, 300)
    }

    //   4   //

    if (a == 4) {
        gciX(-300, 100)
    }

    //   5   //

    if (a == 5) {
        gciX(-100, 100)
    }

    //   6   //

    if (a == 6) {
        gciX(100, 100)
    }

    //   7   //

    if (a == 7) {
        gciX(-300, -100)
    }

    //   8   //

    if (a == 8) {
        gciX(-100, -100)
    }

    //   9   //

    if (a == 9) {
        gciX(100, -100)
    }

    //   Shrjan   //

    //   11   //

    if (a == 11) {
        gciO(-250, 200)
    }

    //   22   //

    if (a == 22) {
         gciO(-50, 200)
    }

    //   33   //

    if (a == 33) {
         gciO(150, 200)
    }

    //   44   //

    if (a == 44) {
         gciO(-250, 0)
    }

    //   55   //

    if (a == 55) {
        gciO(-50, 0)
    }

    //   66   //

    if (a == 66) {
        gciO(150, 0)
    }

    //   77   //

    if (a == 77) {
        gciO(-250, -200)
    }

    //   88   //

    if (a == 88) {
       gciO(-50, -200)
    }

    //   99   //

    if (a == 99) {
        gciO(150, -200)
    }
}






